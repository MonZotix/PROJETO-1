let campoIdade;

function setup() {
  createCanvas(800, 800);
  campoIdade = createInput("10");
}

function draw() {
  background(220);
  let idade = campoIdade.value();
  let recomendacao = geraRecomendacao(idade);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade) {
  if(idade >= 10) {
    if(idade >= 14) {
      return "brawl stars";
    } else {
      return "minecraft";
    }
  } else {
    return "bonk.io";
  }
}